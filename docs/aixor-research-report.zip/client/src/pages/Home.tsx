import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const colorData = [
  { name: "Black", value: 35, hex: "#000000" },
  { name: "White", value: 30, hex: "#FFFFFF" },
  { name: "Dark Grey", value: 20, hex: "#1A1A1A" },
  { name: "Light Grey", value: 10, hex: "#808080" },
  { name: "Blue Accent", value: 5, hex: "#0000EE" },
];

const typographyData = [
  { font: "Arapey", usage: "Headings", percentage: 25 },
  { font: "Urbanist", usage: "Body Text", percentage: 60 },
  { font: "Inter Display", usage: "Alt Headings", percentage: 15 },
];

const componentBreakdown = [
  { component: "Navigation", count: 1 },
  { component: "Hero Section", count: 1 },
  { component: "Service Cards", count: 4 },
  { component: "Project Cards", count: 3 },
  { component: "Awards Section", count: 6 },
  { component: "Team Members", count: 4 },
  { component: "Contact Form", count: 1 },
];

const animationTypes = [
  { type: "Fade-in", frequency: "High", duration: "300-500ms" },
  { type: "Slide-up", frequency: "High", duration: "300-500ms" },
  { type: "Parallax", frequency: "Medium", duration: "Continuous" },
  { type: "Scale on Hover", frequency: "High", duration: "150-250ms" },
  { type: "Shadow Enhancement", frequency: "Medium", duration: "150-250ms" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/95 backdrop-blur-sm">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Aixor Website Analysis</h1>
            <p className="text-sm text-slate-400">Complete Design Research Report</p>
          </div>
          <Badge variant="secondary" className="bg-blue-600/20 text-blue-300 border-blue-500/50">
            Design Study
          </Badge>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-6xl mx-auto px-4 py-12">
        {/* Introduction Section */}
        <section className="mb-16 rounded-lg border border-slate-800 bg-slate-900/50 p-8 backdrop-blur-sm">
          <h2 className="mb-4 text-3xl font-bold text-white">Executive Summary</h2>
          <p className="mb-4 text-slate-300 leading-relaxed">
            The Aixor website is a sophisticated modern creative agency template built with Framer. It showcases a premium dark-themed design with minimalist aesthetics, high-quality 3D assets, and smooth animations. The site emphasizes creativity and innovation through its visual presentation, combining professional sophistication with contemporary design trends.
          </p>
          <p className="text-slate-300 leading-relaxed">
            This comprehensive analysis covers all aspects of the website's design, including typography, color palette, components, animations, and overall aesthetic philosophy. The research reveals a carefully crafted design system that prioritizes contrast, whitespace, and visual hierarchy.
          </p>
        </section>

        {/* Tabs for Different Sections */}
        <Tabs defaultValue="colors" className="mb-16 w-full">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="colors" className="text-sm">Colors</TabsTrigger>
            <TabsTrigger value="typography" className="text-sm">Typography</TabsTrigger>
            <TabsTrigger value="components" className="text-sm">Components</TabsTrigger>
            <TabsTrigger value="animations" className="text-sm">Animations</TabsTrigger>
            <TabsTrigger value="design" className="text-sm">Design System</TabsTrigger>
          </TabsList>

          {/* Colors Tab */}
          <TabsContent value="colors" className="space-y-6 mt-6">
            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Color Palette Distribution</CardTitle>
                <CardDescription>Primary colors used throughout the website</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie data={colorData} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}%`} outerRadius={100} fill="#8884d8" dataKey="value">
                      {colorData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.hex} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Color Specifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Primary Background", value: "#000000", rgb: "rgb(0, 0, 0)", usage: "Main page background" },
                    { name: "Primary Text", value: "#FFFFFF", rgb: "rgb(255, 255, 255)", usage: "Headings and body text" },
                    { name: "Secondary Background", value: "#1A1A1A", rgb: "rgb(26, 26, 26)", usage: "Buttons and cards" },
                    { name: "Accent Color", value: "#0000EE", rgb: "rgb(0, 0, 238)", usage: "Interactive elements" },
                  ].map((color, idx) => (
                    <div key={idx} className="flex items-center gap-4 p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                      <div className="w-12 h-12 rounded-lg border border-slate-600" style={{ backgroundColor: color.value }}></div>
                      <div className="flex-1">
                        <p className="font-semibold text-white">{color.name}</p>
                        <p className="text-sm text-slate-400">{color.value} • {color.rgb}</p>
                      </div>
                      <p className="text-sm text-slate-300">{color.usage}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Typography Tab */}
          <TabsContent value="typography" className="space-y-6 mt-6">
            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Font Family Distribution</CardTitle>
                <CardDescription>Typography usage across the website</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={typographyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="font" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                    <Bar dataKey="percentage" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Typography System</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { font: "Arapey", type: "Serif", usage: "Display headings", weight: "400", size: "60-77px" },
                  { font: "Urbanist", type: "Sans-serif", usage: "Body text & UI", weight: "400-600", size: "14-18px" },
                  { font: "Inter Display", type: "Sans-serif", usage: "Alternative headings", weight: "400-700", size: "32-48px" },
                ].map((item, idx) => (
                  <div key={idx} className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-semibold text-white">{item.font}</p>
                        <p className="text-sm text-slate-400">{item.type}</p>
                      </div>
                      <Badge variant="outline" className="text-slate-300">{item.usage}</Badge>
                    </div>
                    <p className="text-xs text-slate-400">Weight: {item.weight} • Size: {item.size}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Components Tab */}
          <TabsContent value="components" className="space-y-6 mt-6">
            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Component Breakdown</CardTitle>
                <CardDescription>Major UI components used in the design</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={componentBreakdown} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis type="number" stroke="#94a3b8" />
                    <YAxis dataKey="component" type="category" stroke="#94a3b8" width={100} />
                    <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                    <Bar dataKey="count" fill="#10b981" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Key Components</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: "Navigation", desc: "Minimalist hamburger menu in top right" },
                  { name: "Hero Section", desc: "Full-width with large serif typography" },
                  { name: "Service Cards", desc: "Titled cards with 3D illustrations and features" },
                  { name: "Project Cards", desc: "Large images with metadata overlay" },
                  { name: "Stats Cards", desc: "Large numbers with bordered design" },
                  { name: "Contact Form", desc: "Clean input fields with message textarea" },
                ].map((comp, idx) => (
                  <div key={idx} className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                    <p className="font-semibold text-white">{comp.name}</p>
                    <p className="text-sm text-slate-400">{comp.desc}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Animations Tab */}
          <TabsContent value="animations" className="space-y-6 mt-6">
            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Animation Types & Frequency</CardTitle>
                <CardDescription>Motion design patterns used throughout</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={animationTypes}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="type" stroke="#94a3b8" angle={-45} height={80} />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                    <Legend />
                    <Line type="monotone" dataKey="duration" stroke="#f59e0b" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Animation Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {animationTypes.map((anim, idx) => (
                  <div key={idx} className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                    <div className="flex justify-between items-center mb-1">
                      <p className="font-semibold text-white">{anim.type}</p>
                      <Badge variant="outline" className="text-slate-300">{anim.frequency}</Badge>
                    </div>
                    <p className="text-sm text-slate-400">Duration: {anim.duration}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Design System Tab */}
          <TabsContent value="design" className="space-y-6 mt-6">
            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Design Principles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { principle: "Contrast-Driven", desc: "Dark backgrounds with bright text for maximum readability" },
                  { principle: "Minimalist", desc: "Limited color palette and clean layouts" },
                  { principle: "Spacious", desc: "Generous whitespace and padding throughout" },
                  { principle: "Typography-Focused", desc: "Bold serif headings with readable sans-serif body" },
                  { principle: "Animation-Enhanced", desc: "Smooth transitions and scroll effects" },
                  { principle: "Professional", desc: "Sophisticated, high-end aesthetic" },
                ].map((item, idx) => (
                  <div key={idx} className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                    <p className="font-semibold text-white">{item.principle}</p>
                    <p className="text-sm text-slate-400">{item.desc}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-slate-800 bg-slate-900/50">
              <CardHeader>
                <CardTitle className="text-white">Layout & Spacing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                  <p className="font-semibold text-white mb-1">Responsive Padding</p>
                  <p className="text-sm text-slate-400">Mobile: 16px • Tablet: 24px • Desktop: 32px</p>
                </div>
                <div className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                  <p className="font-semibold text-white mb-1">Section Spacing</p>
                  <p className="text-sm text-slate-400">Large vertical gaps between sections (100px+)</p>
                </div>
                <div className="p-3 rounded-lg border border-slate-700 bg-slate-800/30">
                  <p className="font-semibold text-white mb-1">Grid System</p>
                  <p className="text-sm text-slate-400">Flexible, spacious grid with asymmetric layouts</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Key Insights Section */}
        <section className="mb-16 grid gap-6 md:grid-cols-2">
          <Card className="border-slate-800 bg-slate-900/50">
            <CardHeader>
              <CardTitle className="text-white">Visual Aesthetics</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 space-y-3">
              <p>The website employs a dark luxury aesthetic with black backgrounds and white typography. This creates exceptional contrast and a premium feel that appeals to creative professionals.</p>
              <p>The minimalist approach focuses on content and high-quality 3D assets rather than decorative elements, resulting in a sophisticated and contemporary appearance.</p>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900/50">
            <CardHeader>
              <CardTitle className="text-white">Interactive Experience</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 space-y-3">
              <p>Smooth animations and transitions enhance user engagement without overwhelming the interface. Fade-in effects, slide-up animations, and parallax effects create depth.</p>
              <p>Hover states provide immediate visual feedback, making the interface feel responsive and interactive while maintaining the minimalist aesthetic.</p>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900/50">
            <CardHeader>
              <CardTitle className="text-white">Typography Strategy</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 space-y-3">
              <p>The combination of Arapey serif for headings and Urbanist sans-serif for body text creates visual hierarchy and distinction. This pairing balances elegance with readability.</p>
              <p>Large, bold headings command attention while maintaining the sophisticated aesthetic, and the clean body text ensures excellent readability across all devices.</p>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900/50">
            <CardHeader>
              <CardTitle className="text-white">Component Design</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 space-y-3">
              <p>Components follow a consistent design language with pill-shaped buttons, bordered cards, and clean form inputs. Each element serves a clear purpose in the user journey.</p>
              <p>The design system supports both visual consistency and functional clarity, with high contrast ensuring accessibility while maintaining the premium aesthetic.</p>
            </CardContent>
          </Card>
        </section>

        {/* Conclusion */}
        <section className="rounded-lg border border-slate-800 bg-gradient-to-r from-blue-900/20 to-slate-900/50 p-8 backdrop-blur-sm">
          <h2 className="mb-4 text-2xl font-bold text-white">Key Takeaways</h2>
          <ul className="space-y-2 text-slate-300">
            <li className="flex items-start gap-3">
              <span className="text-blue-400 font-bold">•</span>
              <span>The Aixor design exemplifies modern web design with its sophisticated dark theme and minimalist approach</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-blue-400 font-bold">•</span>
              <span>Strategic use of typography, color, and whitespace creates a premium, professional impression</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-blue-400 font-bold">•</span>
              <span>Smooth animations and interactive elements enhance user engagement without sacrificing minimalism</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-blue-400 font-bold">•</span>
              <span>High contrast ratios and clear typography ensure excellent accessibility and readability</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-blue-400 font-bold">•</span>
              <span>The design system balances visual richness with functional simplicity, creating a compelling user experience</span>
            </li>
          </ul>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-8 mt-16">
        <div className="container max-w-6xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p>Aixor Website Analysis Report • Comprehensive Design Research</p>
          <p className="mt-2">This analysis covers UI, typography, colors, components, animations, and overall design philosophy</p>
        </div>
      </footer>
    </div>
  );
}
